<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Raceclass extends Model
{
    /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $fillable = [
        'class_name '
    ];
}
