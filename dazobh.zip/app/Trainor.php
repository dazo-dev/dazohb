<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Trainor extends Model
{
    /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $fillable = [
        'trainor_name '
    ];
}
