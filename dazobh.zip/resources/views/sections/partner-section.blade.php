<div class="partner-section">

	<div class="inner-block">
		
		<div class="row">
			
			<div class="col-sm-8 col-lg-8 col-12 inner-left">
				
				<div class="row inner-inner-head">
					GUIDING YOU FOR DECADES
				</div>
				<div class="row inner-inner-sub">
					Dividendazo Since 1932
				</div>
				<div class="row inner-inner-content">
					Lorem ipsum dolor sit amet, consectetuer adipiscing elit. aenean commodo ligula eget dolor. Aenean massa cum sociis natoque nullam penatibus et magnis dis parturient montes, nascetur.
				</div>
				<div class="row inner-inner-button">
					<button>MORE ABOUT US</button>
				</div>

			</div>

			<div class="col-sm-4 col-lg-4 col-12 inner-right">
				<img class="winnerlogo" src="images/logomid.png">
				<img class="floating-horse" src="images/horse-2.png">
			</div>

			

		</div>



	</div>

	{{-- ADD PARTNER HERE --}}
	<div class="row partner-header">
		<div class="col-sm-3 h-sect1">OUR PARTNERS</div>
		<div class="col-sm-9 h-sect2"></div>
	</div>

	<div class="row partners-logo">
		<div class="col-sm-2 img-1">
			<img src="images/cropped-logo.png">
		</div>
		<div class="col-sm-3 cont-1">
			<h5>Philracom</h5>
			<p>www.philracom.gov.ph</p>
		</div>
		<div class="col-sm-3 img-2">
			<img src="images/logo-MMTC.png" style="position: absolute; top: -30px; left: 25%;">
		</div>
		<div class="col-sm-4 cont-2">
			<h5>Metro Turf Club Inc.</h5>
			<p>www.mmtci.com</p>
		</div>
	</div>

</div>