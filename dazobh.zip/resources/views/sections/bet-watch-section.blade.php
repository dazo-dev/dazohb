<div class="bet-watch-section">
	<div class="col-sm-12 p-0 display-flex display-block-mb">
		<div class="col-lg-6 col-sm-12 watch-flex">
			<div class="watch-overlay w-100">
				<div class="row header">
					<p>Watch Live Horse Races Online</p>
					
				</div>
				<div class="row sub">
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
				</div>
				<div class="row btn">
					<button>
						Watch Livestream <i class="fas fa-caret-right"></i>
					</button>
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-sm-12 bet-flex">
			<div class="bet-overlay w-100">
				<div class="row header m-0">
					<p>Place Your Bet Today!</p>
				</div>
				<div class="row sub m-0">
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
				</div>
				<div class="row btn">
					<button>
						bet now <i class="fas fa-caret-right"></i>
					</button>
				</div>
			</div>
		</div>
	</div>
</div>