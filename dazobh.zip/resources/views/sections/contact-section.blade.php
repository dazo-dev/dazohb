<div class="contact-section" style="outline-width: 0;">
  <div class="row">
    <div class="col-sm-7"></div>
    <div class="col-sm-5">
      <div class="inner-block" id='card'>
        <div class="inner-block-title">Contact Us</div>
        <div class="inner-block-content">
          It is a long established fact that a reader will be distracted by the
          readable content of a page when looking at its layout.
        </div>
        <div class="inner-block-form">
          <div class="input-block-wrapper">
            <input class="form-control" name="fullName" autocomplete="off" placeholder="Name" />
          </div>
          <div class="input-block-wrapper">
            <input class="form-control" name="mobile" autocomplete="off" placeholder="Contact Number" />
          </div>
          <div class="input-block-wrapper">
            <input class="form-control" name="email" autocomplete="off" placeholder="Email Address" />
          </div>
          <div class="input-block-wrapper">
            <textarea class="form-control" rows="6" name="message" autocomplete="off" placeholder="Message"></textarea>
          </div>
          <div class="input-block-wrapper btn-wrapper">
            <button class="form-control">
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>