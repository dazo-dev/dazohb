<!-- <div class="row pro-package">
	<div class="col-sm-6 col-lg-6 col-12 right-pro-block">
		<h2>Pro Subscription Packages</h2>
		<p class="sub-content">Bibendum ridiculus ullamcorper vel odio gravida duis nec fringilla.</p>

		<p class="f-v">early race program with dividendazo tips</p>
		<p>last week & same day race result with dividends</p>
		<p>instant Video replay after the race</p>
		<p>make your own race card</p>
		<p>Handicap indicator per entries</p>
		<p>find the nearest OTB IN YOUR LOCATION</p>
		<p>last 1 race of entries chart</p>
		<p>last 5 races of entries chart</p>
		<p>last 5 races of same distance entries chart</p>
		<p>live DD betting sales</p>
		<p>1 year race results with dividends & Replays</p>
		<p>chat room with fellow pro ka-dazos</p>
		<p>exclusive tipster video analysis</p>
	</div>


	<div class="col-sm-6 col-lg-6 col-12 left-pro-block">
		<div class="row" style="height: 5vh">
			<div class="col-12 col-sm-4 col-lg-4 col-md-4"></div>
			<div class="col-12 col-sm-8 col-lg-8 col-md-8">
				<h4>pro subscription</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-6 col-md-3 col-lg-3 col-sm-3" style="background-color: #000000; padding: 0">
				<div class="pointe-block-3">
					<h2>daily packages</h2>
					<p class="sub-content"><img src="images/DazoCoin-png.png">100</p>
				</div>
				<p style="margin-top: 3.5vh;">✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>&nbsp</p>
				<p>&nbsp</p>
				<p>&nbsp</p>
				<p>&nbsp</p>
				<p>&nbsp</p>
				<p>&nbsp</p>
			</div>
			<div class="col-6 col-md-1 col-lg-1 col-sm-1" style="background-color: #000000; padding: 0"></div>
			<div class="col-6 col-md-4 col-lg-4 col-sm-4" style="background-color: #000000; padding: 0">
				<div class="pointe-block-4">
					<h2>monthly packages</h2>
					<p class="sub-content-img"><img src="images/DazoCoin-png.png">100</p>
				</div>
				<p class="f-p">✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
			</div>
			<div class="col-6 col-md-4 col-lg-4 col-sm-4" style="background-color: #000000; padding: 0">
				<div class="pointe-block-4">
					<h2>yearly packages</h2>
					<p class="sub-content-img"><img src="images/DazoCoin-png.png">100</p>
				</div>
				<p class="f-p">✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
				<p>✓</p>
			</div>
		</div>
	</div>
</div> -->

<div class="row pro-package-2">
	
	<div class="col-sm-12">
		<table>
			
			<thead>
			<tr>
				<td></td>
				<td></td>
				<td></td>
				<td colspan=2 class="pro-subs-header">PRO SUBSCRIPTION</td>
				
			</tr>
				<th class="header-package-main-col">
					<h2>Pro Subscription Packages</h2>
					<p class="sub-content">Bibendum ridiculus ullamcorper vel odio gravida duis nec fringilla.</p>
				</th>
				<th class="header-packages-col header-bg-color pointed-block">
					<p class="header-text">DAILY PACKAGES</p>
					<p class="sub-content"><img src="images/DazoCoin-png.png">20</p>
				</th>
				<th class="header-blank-col">
					<img src="images/plus-icon.png" alt="">
				</th>
				<th class="header-packages-col pointed-block border-right-black">
					<p class="header-text">MONTHLY PACKAGES</p>
					<p class="sub-content"><img src="images/DazoCoin-png.png">300</p>
				</th>
				<th class="header-packages-col pointed-block">
					<p class="header-text">YEARLY PACKAGES</p>
					<p class="sub-content"><img src="images/DazoCoin-png.png">1000</p>
				</th>
			</thead>
			<tbody>
				<tr style="height:28px">
					<td style="border-bottom: none;"></td>
					<td style="border-bottom: none;background-color: #0000006e;"></td>
					<td style="border-bottom: none;"></td>
					<td style="border-bottom: none;background-color: #0000006e;"></td>
					<td style="border-bottom: none;background-color: #0000006e;"></td>
				</tr>
			<tr>
				<td>
					<p>EARLY RACE PROGRAM WITH DIVIDENDAZO TIPS</p>
				</td>
				<td class="col-check"><p>✓</p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>LAST WEEK & SAME DAY RACE RESULT WITH DIVIDENDS</p>
				</td>
				<td class="col-check"><p>✓</p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>INSTANT VIDEO REPLAY AFTER THE RACE</p>
				</td>
				<td class="col-check"><p>✓</p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>MAKE YOUR OWN RACE CARD</p>
				</td>
				<td class="col-check"><p>✓</p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>HANDICAP INDICATOR PER ENTRIES</p>
				</td>
				<td class="col-check"><p>✓</p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>FIND THE NEAREST OTB IN YOUR LOCATION</p>
				</td>
				<td class="col-check"><p>✓</p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>LAST 1 RACE OF ENTRIES CHART</p>
				</td>
				<td class="col-check"><p>✓</p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>LAST 5 RACES OF ENTRIES CHART</p>
				</td>
				<td class="col-check"><p></p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>LAST 5 RACES OF SAME DISTANCE ENTRIES CHART</p>
				</td>
				<td class="col-check"><p></p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>LIVE DD BETTING SALES</p>
				</td>
				<td class="col-check"><p></p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>1 YEAR RACE RESULTS WITH DIVIDENDS & REPLAYS</p>
				</td>
				<td class="col-check"><p></p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>CHAT ROOM WITH FELLOW PRO KA-DAZOS</p>
				</td>
				<td class="col-check"><p></p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td>
					<p>EXCLUSIVE TIPSTER VIDEO ANALYSIS</p>
				</td>
				<td class="col-check"><p></p></td>
				<td class="content-blank-col"><p></p></td>
				<td class="col-check"><p>✓</p></td>
				<td class="col-check"><p>✓</p></td>
			</tr>
			<tr>
				<td style="border:none;"></td>
				<td style="border:none;"></td>
				<td style="border:none;"><p></p></td>
				<td class="col-check border-left"> 
					<button class="subscribe-btn">
						SUBSCRIBE
					</button>
				</td>
				<td class="col-check">
					<button class="subscribe-btn">
						SUBSCRIBE
					</button>
				</td>
			</tr>
			</tbody>
		</table>
	</div>
</div>

<div class="row pro-package-3">
	<div class="col-sm-12" style="margin-bottom:68px;">
		<div class="row">
			<div class="col-12">
				<h1>Pro Subscription Package</h1>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<p>Bibendum ridiculus ullamcorper vel odio gravida duis nec fringilla.</p>
			</div>
		</div>
	</div>

	<div class="col-sm-12">
		<div class="row">
			<div class="col-12">
				<table>
					<thead>
						<th colspan=2 class="pointed-block-mb">
							<p class="header-text">DAILY PACKAGES</p>
							<p class="sub-content"><img src="images/DazoCoin-png.png">20</p>
						</th>
					</thead>
					<tbody>
						<tr class="blank-col">
							<td></td>
							<td></td>
						</tr>
						<tr>
							<td class="col-text"><p>EARLY RACE PROGRAM WITH DIVIDENDAZO TIPS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST WEEK & SAME DAY RACE RESULT WITH DIVIDENDS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>INSTANT VIDEO REPLAY AFTER THE RACE</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>MAKE YOUR OWN RACE CARD</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>HANDICAP INDICATOR PER ENTRIES</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>FIND THE NEAREST OTB IN YOUR LOCATION</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST 1 RACE OF ENTRIES CHART</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="col-12 col-plus-sign">
				<img src="images/plus-icon.png" alt="">
			</div>

			<div class="col-12 col-pro-subs-header">
			<p class="pro-subs-header-text">PRO SUBSCRIPTION</p>	
			</div>
			<div class="col-12">
				<table>
					<thead>
						<th colspan=2 class="pointed-block-mb">
							<p class="header-text">MONTHLY PACKAGES</p>
							<p class="sub-content"><img src="images/DazoCoin-png.png">300</p>
						</th>
					</thead>
					<tbody> 
						<tr class="blank-col">
							<td></td>
							<td></td>
						</tr>
						<tr>
							<td class="col-text"><p>EARLY RACE PROGRAM WITH DIVIDENDAZO TIPS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST WEEK & SAME DAY RACE RESULT WITH DIVIDENDS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>INSTANT VIDEO REPLAY AFTER THE RACE</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>MAKE YOUR OWN RACE CARD</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>HANDICAP INDICATOR PER ENTRIES</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>FIND THE NEAREST OTB IN YOUR LOCATION</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST 1 RACE OF ENTRIES CHART</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST 5 RACES OF ENTRIES CHART</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST 5 RACES OF SAME DISTANCE ENTRIES CHART</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LIVE DD BETTING SALES</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>1 YEAR RACE RESULTS WITH DIVIDENDS & REPLAYS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>CHAT ROOM WITH FELLOW PRO KA-DAZOS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>EXCLUSIVE TIPSTER VIDEO ANALYSIS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="col-12 col-pro-subs-header">
			<p class="pro-subs-header-text">PRO SUBSCRIPTION</p>	
			</div>
			<div class="col-12">
				<table>
					<thead>
						<th colspan=2 class="pointed-block-mb">
							<p class="header-text">YEARLY PACKAGES</p>
							<p class="sub-content"><img src="images/DazoCoin-png.png">1000</p>
						</th>
					</thead>
					<tbody>
					<tr class="blank-col">
							<td></td>
							<td></td>
						</tr>
						<tr>
							<td class="col-text"><p>EARLY RACE PROGRAM WITH DIVIDENDAZO TIPS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST WEEK & SAME DAY RACE RESULT WITH DIVIDENDS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>INSTANT VIDEO REPLAY AFTER THE RACE</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>MAKE YOUR OWN RACE CARD</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>HANDICAP INDICATOR PER ENTRIES</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>FIND THE NEAREST OTB IN YOUR LOCATION</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST 1 RACE OF ENTRIES CHART</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST 5 RACES OF ENTRIES CHART</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LAST 5 RACES OF SAME DISTANCE ENTRIES CHART</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>LIVE DD BETTING SALES</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>1 YEAR RACE RESULTS WITH DIVIDENDS & REPLAYS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>CHAT ROOM WITH FELLOW PRO KA-DAZOS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
						<tr>
							<td  class="col-text"><p>EXCLUSIVE TIPSTER VIDEO ANALYSIS</p></td>
							<td class="col-check"><p>✓</p></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- <div class="row pro-package-2">
	<div class="col-sm-12">	
		<div class="row">
			<div class="col-sm-5">
				<div class="row">
					<h2>Pro Subscription Packages</h2>
					<p class="sub-content">Bibendum ridiculus ullamcorper vel odio gravida duis nec fringilla.</p>
				</div>
				<div class="row"><p>EARLY RACE PROGRAM WITH DIVIDENDAZO TIPS</p></div>
				<div class="row"><p>LAST WEEK & SAME DAY RACE RESULT WITH DIVIDENDS</p></div>
				<div class="row"><p>INSTANT VIDEO REPLAY AFTER THE RACE</p></div>
				<div class="row"><p>MAKE YOUR OWN RACE CARD</p></div>
				<div class="row"><p>HANDICAP INDICATOR PER ENTRIES</p></div>
				<div class="row"><p>FIND THE NEAREST OTB IN YOUR LOCATION</p></div>
				<div class="row"><p>LAST 1 RACE OF ENTRIES CHART</p></div>
				<div class="row"><p>LAST 5 RACES OF ENTRIES CHART</p></div>
				<div class="row"><p>LAST 5 RACES OF SAME DISTANCE ENTRIES CHART</p></div>
				<div class="row"><p>LIVE DD BETTING SALES</p></div>
				<div class="row"><p>1 YEAR RACE RESULTS WITH DIVIDENDS & REPLAYS</p></div>
				<div class="row"><p>CHAT ROOM WITH FELLOW PRO KA-DAZOS</p></div>
				<div class="row"><p>EXCLUSIVE TIPSTER VIDEO ANALYSIS</p></div>
			</div>
			<div class="col-sm-2">
				<div class="row">
					<p>DAILY PACKAGE</p>		
					<p class="sub-content"><img src="images/DazoCoin-png.png">100</p>
				</div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>&nbsp</p></div>
				<div class="row"><p>&nbsp</p></div>
				<div class="row"><p>&nbsp</p></div>
				<div class="row"><p>&nbsp</p></div>
				<div class="row"><p>&nbsp</p></div>
				<div class="row"><p>&nbsp</p></div>
			</div>
			<div class="col-sm-1">
				
			</div>
			<div class="col-sm-2">
				<div class="row">
					<p>MONTHLY PACKAGE</p>
					<p class="sub-content"><img src="images/DazoCoin-png.png">100</p>
				</div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
			</div>
			<div class="col-sm-2">
				<div class="row">
					<p>YEARLY PACKAGE</p>
					<p class="sub-content"><img src="images/DazoCoin-png.png">100</p>
				</div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
				<div class="row"><p>✓</p></div>
			</div>
		</div>
	</div> -->
</div>

