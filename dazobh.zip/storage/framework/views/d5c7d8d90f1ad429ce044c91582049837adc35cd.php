<div class="modal fade" id="modal-calendar" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="z-index:9999;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="height: 64vh; background-color: #000; color: #fff; width:96%">
            <button type="button" style="display: none" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         <!-- <div class="modal-header">
       
            </div> -->
            <div class="modal-body">
                <div class="row">
                    <header>
                        <div class="title-content">
                            <button id="last"></button>
                                <span>
                                    <h1 id="month"></h1>
                                </span>
                            <button id="next"></button>
                        </div>
                    </header>
                    <div class="ci-cal-container" id="calendar"></div>
                </div>
            </div>
        <div>
    </div>
</div>
 <?php /**PATH D:\xampp\htdocs\dazohb\resources\views/modals/calendar.blade.php ENDPATH**/ ?>