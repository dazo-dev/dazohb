
<div class="modal fade" id="loadMe" tabindex="-1" role="dialog" aria-labelledby="loadMeLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <div class="loader"></div>
        <div clas="loader-txt">
          <p>Processing request...<br><br><small>Please Wait...</small></p>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\xampp\htdocs\dazohb\resources\views/modals/loading.blade.php ENDPATH**/ ?>