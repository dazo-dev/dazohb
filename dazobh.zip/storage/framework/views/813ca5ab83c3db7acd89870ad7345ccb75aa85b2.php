<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="margin-top: 2%">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="row">
        <div class="col-sm-6">
          <div class="d-block w-50">
        <div class="row block-header">CREATE YOUR ACCOUNT TODAY</div>
        <div class="row block-sub">Get Updated with Every Race Results and Details</div>
        <div class="row block-content">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</div>
        <div class="row block-btn">
          <button data-toggle="modal" data-target="#registerModal">SIGN UP NOW</button>
        </div>
      </div>
        </div>
        <div class="col-sm-6">
          <img class="d-block w-100" src="images/calendar.png" alt="First slide" style="height: 300px !important">
        </div>
      </div>
      
      
    </div>
  </div>
  
</div><?php /**PATH D:\xampp\htdocs\dazobh\resources\views/sections/calendar-section.blade.php ENDPATH**/ ?>