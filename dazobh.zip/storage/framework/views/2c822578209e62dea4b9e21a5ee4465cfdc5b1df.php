<div class="bet-watch-section">
	<div class="row">
		<div class="col-sm-6 col-12 watch-flex">
			<div class="watch-overlay">
				<div class="row header">
					<p>Watch Live Horse Races Online</p>
					
				</div>
				<div class="row sub">
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
				</div>
				<div class="row btn">
					<button>
						Watch Livestream <i class="fas fa-caret-right"></i>
					</button>
				</div>
			</div>
		</div>
		<div class="col-sm-6 col-12 bet-flex">
			<div class="bet-overlay">
				<div class="row header">
					<p>Place Your Bet Today!</p>
				</div>
				<div class="row sub">
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
				</div>
				<div class="row btn">
					<button>
						bet now <i class="fas fa-caret-right"></i>
					</button>
				</div>
			</div>
		</div>
	</div>
</div><?php /**PATH D:\xampp\htdocs\dazobh\resources\views/sections/bet-watch-section.blade.php ENDPATH**/ ?>