<div class="modal fade" id="notiModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <button type="button" style="display: none" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      <div class="modal-header">
        <!-- <h5 class="modal-title" id="signinModalTitle">
          <img src="images/check.png">
        </h5> -->
        <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
          <circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
          <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
        </svg>
      </div>
      <div class="modal-body">
        <div class="row">
          <p>
            Congratulations, you've successfully created your account! You may now log in using your details.
          </p>
        </div>
        <button class="btn-red-login">LOG IN</button> 
      </div>
    </div>
  </div>
</div><?php /**PATH D:\xampp\htdocs\dazohb\resources\views/modals/notification.blade.php ENDPATH**/ ?>