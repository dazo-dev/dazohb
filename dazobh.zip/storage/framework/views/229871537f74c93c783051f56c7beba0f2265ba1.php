<div class="footer-section">
	<div class="row">
		<p>Copyright 2020 Dividendazo. All rights reserved.</p>
	</div>
</div><?php /**PATH D:\xampp\htdocs\dazohb\resources\views/sections/footer-section.blade.php ENDPATH**/ ?>